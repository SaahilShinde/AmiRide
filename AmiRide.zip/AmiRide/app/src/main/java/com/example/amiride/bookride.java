package com.example.amiride;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import java.util.List;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
public class bookride extends AppCompatActivity {
    private RecyclerView recyclerView;
    private ItemAdapter adapter;
    private List<publishridedb> itemList;
    String formattedTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bookride);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        itemList = new ArrayList<>();
        adapter = new ItemAdapter(itemList, this);
        recyclerView.setAdapter(adapter);

        // Firebase Database reference
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("PublishRides");
        LocalTime currentTime = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            currentTime = LocalTime.now();
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            double currentHour = currentTime.getHour()
                    + currentTime.getMinute() / 60.0
                    + currentTime.getSecond() / 3600.0
                    + currentTime.getNano() / 3_600_000_000_000.0;
            formattedTime=""+currentHour;
        }
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                itemList.clear();
                for (DataSnapshot data : snapshot.getChildren()) {
                    publishridedb item = data.getValue(publishridedb.class);
                /*    double time1=Double.parseDouble(item.getTime1().toString());
                    double time2=time1+4.00;
                    double currentTime=Double.parseDouble(formattedTime);
                    System.out.println("after 4 hr time="+time2);
        System.out.println("current time="+currentTime);
                    if(currentTime<=time2)
                    {*/
                    if (item != null) {
                        itemList.add(item);
                    }
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("FirebaseError", error.getMessage());
            }
        });
    }
}
