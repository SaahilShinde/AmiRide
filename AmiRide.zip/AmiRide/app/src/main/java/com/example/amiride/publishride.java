package com.example.amiride;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class publishride extends AppCompatActivity {
String from1, time1,con1 ,vehno1, descri1;
DatabaseReference db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_publishride);
        db = FirebaseDatabase.getInstance().getReference("PublishRides");
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ImageView back = findViewById(R.id.imageView6);
        back.setOnClickListener(v -> {
            finish();
        });

        Button nex = findViewById(R.id.next);
        EditText from = findViewById(R.id.frm);
        EditText time = findViewById(R.id.tim);
        EditText con = findViewById(R.id.con);
        EditText vehno = findViewById(R.id.veh);
        EditText descri = findViewById(R.id.des);

        nex.setOnClickListener(v -> {
            from1 = from.getText().toString();
            time1 = time.getText().toString();
            con1 = con.getText().toString();
            vehno1 = vehno.getText().toString();
            descri1 = descri.getText().toString();
            if (from.getText().toString().isEmpty() || time.getText().toString().isEmpty() || vehno.getText().toString().isEmpty() || descri.getText().toString().isEmpty()) {
                Toast.makeText(publishride.this, "Fill all fields", Toast.LENGTH_SHORT).show();
            } else {

                publishridedb p = new publishridedb(from1, time1, con1,vehno1, descri1);
                db.child(vehno1).setValue(p);
                Toast.makeText(publishride.this, "Ride Published", Toast.LENGTH_SHORT).show();
                finish();
            }
            });
        }
    }
