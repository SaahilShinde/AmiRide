package com.example.amiride;

public class publishridedb {
    public publishridedb() {

    }

    String from1, time1,con1 ,vehno1, descri1;

    public publishridedb(String from1, String time1, String con1, String vehno1, String descri1) {
        this.from1 = from1;
        this.time1 = time1;
        this.con1 = con1;
        this.vehno1 = vehno1;
        this.descri1 = descri1;
    }

    public String getFrom1() {
        return from1;
    }

    public void setFrom1(String from1) {
        this.from1 = from1;
    }

    public String getTime1() {
        return time1;
    }

    public void setTime1(String time1) {
        this.time1 = time1;
    }

    public String getCon1() {
        return con1;
    }

    public void setCon1(String con1) {
        this.con1 = con1;
    }

    public String getVehno1() {
        return vehno1;
    }

    public void setVehno1(String vehno1) {
        this.vehno1 = vehno1;
    }

    public String getDescri1() {
        return descri1;
    }

    public void setDescri1(String descri1) {
        this.descri1 = descri1;
    }
}
