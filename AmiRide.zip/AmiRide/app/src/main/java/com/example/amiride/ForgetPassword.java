package com.example.amiride;

import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class ForgetPassword extends AppCompatActivity {
DatabaseReference db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_forget_password);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        db= FirebaseDatabase.getInstance().getReference().child("StudentSignup");
        EditText e1=findViewById(R.id.e1);
        Button btn=findViewById(R.id.btn);
        if (checkPermission(android.Manifest.permission.SEND_SMS))
        {
            btn.setEnabled(true);
        }
        else {
            ActivityCompat.requestPermissions(ForgetPassword.this,
                    new String[]{android.Manifest.permission.SEND_SMS}
                    , 1);

        }
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String enroll=e1.getText().toString();
                db.child(enroll).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DataSnapshot> task) {
                        String pass1=task.getResult().child("pass1").getValue(String.class);
                        String contact1=task.getResult().child("conta1").getValue(String.class);
                        Intent i=new Intent();
                        PendingIntent pi=PendingIntent.getActivity(ForgetPassword.this,
                                0,i,PendingIntent.FLAG_IMMUTABLE);
                        SmsManager sms=SmsManager.getDefault();
                        sms.sendTextMessage(contact1, null, "Your password is "+pass1, pi,null);

                        Toast.makeText(ForgetPassword.this, "Message Sent successfully!",
                                Toast.LENGTH_LONG).show();


                    }
                });

            }
        });}
        public boolean checkPermission(String permission) {
            int check = ContextCompat.checkSelfPermission
                    (this, permission);
            return (check == PackageManager.PERMISSION_GRANTED);
        }}
