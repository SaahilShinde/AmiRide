package com.example.amiride;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Random;

public class sendsms extends AppCompatActivity {
    EditText mobile,msg;
    Button btn;
    String mobileno,message;
    DatabaseReference db;
    EditText enroll;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sendsms);

        ImageView back = findViewById(R.id.imageView6);
        back.setOnClickListener(v -> {
            finish();
        });

        mobile=findViewById(R.id.mobileno);
        msg=findViewById(R.id.msg);
        btn=findViewById(R.id.btn);
        enroll=findViewById(R.id.enroll);
        mobileno = getIntent().getStringExtra("mob");
        String from = getIntent().getStringExtra("from");
        String time = getIntent().getStringExtra("time");
        String decrip = getIntent().getStringExtra("decrip");
        String vehicleno = getIntent().getStringExtra("vehicleno");
        db = FirebaseDatabase.getInstance().getReference("BookRides");
        mobile.setText(mobileno);
        if (checkPermission(android.Manifest.permission.SEND_SMS))
        {
            btn.setEnabled(true);
        }
        else {
            ActivityCompat.requestPermissions(sendsms.this,
                    new String[]{android.Manifest.permission.SEND_SMS}
                    , 1);

        }
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String enroll1=enroll.getText().toString();
                BookRideDB bookRideDB=new BookRideDB(enroll1,mobileno,from,time,decrip,vehicleno);
                db.child(enroll1).setValue(bookRideDB);

                message=msg.getText().toString();
                Intent i=new Intent();
                PendingIntent pi=PendingIntent.getActivity(sendsms.this,
                        0,i,PendingIntent.FLAG_IMMUTABLE);
                SmsManager sms=SmsManager.getDefault();
                sms.sendTextMessage(mobileno, null, message, pi,null);

                Toast.makeText(sendsms.this, "Message Sent successfully!",
                        Toast.LENGTH_LONG).show();

            }
        });

    }
    public boolean checkPermission(String permission) {
        int check = ContextCompat.checkSelfPermission
                (this, permission);
        return (check == PackageManager.PERMISSION_GRANTED);
    }}