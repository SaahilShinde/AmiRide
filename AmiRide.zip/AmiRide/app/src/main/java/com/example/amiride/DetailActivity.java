package com.example.amiride;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class DetailActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        EditText frm, tim, con, veh, des;
        frm = findViewById(R.id.frm);
        tim = findViewById(R.id.tim);
        con = findViewById(R.id.con);
        veh = findViewById(R.id.veh);
        des = findViewById(R.id.des);
        String name = getIntent().getStringExtra("from");
        String details = getIntent().getStringExtra("contactno");
        String decrip = getIntent().getStringExtra("decrip");
        String vehicleno = getIntent().getStringExtra("vehicleno");
        String time = getIntent().getStringExtra("time");

        frm.setText(name);
        tim.setText(time);
        des.setText(decrip);
        con.setText(details);
        veh.setText(vehicleno);
        Button btn = findViewById(R.id.next);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DetailActivity.this, sendsms.class);
                intent.putExtra("mob", details);
                intent.putExtra("from", name);
                intent.putExtra("time", time);
                intent.putExtra("decrip", decrip);
                intent.putExtra("vehicleno", vehicleno);
                startActivity(intent);
            }
        });

        ImageView back = findViewById(R.id.imageView6);
        back.setOnClickListener(v -> {
            finish();
        });

    }
    }

