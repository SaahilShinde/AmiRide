package com.example.amiride;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class DetailActivity1 extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail1);

        EditText frm;
        EditText to;
        EditText tim;
        EditText con;
        EditText veh;
        EditText des;
        to = findViewById(R.id.to);
        tim = findViewById(R.id.tim);
        con = findViewById(R.id.con);
        veh = findViewById(R.id.veh);
        des = findViewById(R.id.des);
        frm = findViewById(R.id.frm);
      String enroll= getIntent().getStringExtra("from");
      String contactno= getIntent().getStringExtra("contactno");
      String decrip= getIntent().getStringExtra("decrip");
      String vehicleno= getIntent().getStringExtra("vehicleno");
      String time= getIntent().getStringExtra("time");
      tim.setText(time);
      con.setText(contactno);
      veh.setText(vehicleno);
      des.setText(decrip);
      frm.setText(enroll);

        ImageView back = findViewById(R.id.imageView6);
        back.setOnClickListener(v -> {
            finish();
        });
    }
}

