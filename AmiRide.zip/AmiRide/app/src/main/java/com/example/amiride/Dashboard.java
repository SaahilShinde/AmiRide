package com.example.amiride;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Dashboard extends AppCompatActivity {
DatabaseReference db;
String abc1, xyz1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_dashboard);
        db = FirebaseDatabase.getInstance().getReference().child("StudentSignup");
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
TextView forgetpass=findViewById(R.id.forgetpass);

        EditText abc, xyz;
        abc = findViewById(R.id.uname);
        xyz = findViewById(R.id.passs);

        TextView textLink = findViewById(R.id.textView8);
        textLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to NextActivity
                Intent intent = new Intent(Dashboard.this, signup.class);
                startActivity(intent);
            }
        });
forgetpass.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        Intent i=new Intent(Dashboard.this,ForgetPassword.class);
        startActivity(i);
    }
});
        Button login = findViewById(R.id.next);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(abc.getText().toString().isEmpty() || xyz.getText().toString().isEmpty()){
                    Toast.makeText(Dashboard.this, "Fill all fields", Toast.LENGTH_SHORT).show();
                }
                else {
                    abc1 = abc.getText().toString();
                    xyz1 = xyz.getText().toString();
                    db.child(abc1).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<DataSnapshot> task) {

                            if(xyz1.equals(task.getResult().child("pass1").getValue(String.class)))
                            {

                                Toast.makeText(Dashboard.this, "Login Successful!", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(Dashboard.this, dashboard1.class);
                                intent.putExtra("enroll", abc1); // Attach the data
                                startActivity(intent);
                               // startActivity(intent);
                            }
                        }
                    });
                }
            }
        });


    }
}