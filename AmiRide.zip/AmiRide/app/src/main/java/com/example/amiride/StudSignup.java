package com.example.amiride;

public class StudSignup {
    String fname1, lname1, conta1, emai1, user1, pass1;

    public StudSignup(String fname1, String lname1, String conta1, String emai1, String user1, String pass1) {
        this.fname1 = fname1;
        this.lname1 = lname1;
        this.conta1 = conta1;
        this.emai1 = emai1;
        this.user1 = user1;
        this.pass1 = pass1;
    }

    public String getFname1() {
        return fname1;
    }

    public void setFname1(String fname1) {
        this.fname1 = fname1;
    }

    public String getLname1() {
        return lname1;
    }

    public void setLname1(String lname1) {
        this.lname1 = lname1;
    }

    public String getConta1() {
        return conta1;
    }

    public void setConta1(String conta1) {
        this.conta1 = conta1;
    }

    public String getEmai1() {
        return emai1;
    }

    public void setEmai1(String emai1) {
        this.emai1 = emai1;
    }

    public String getUser1() {
        return user1;
    }

    public void setUser1(String user1) {
        this.user1 = user1;
    }

    public String getPass1() {
        return pass1;
    }

    public void setPass1(String pass1) {
        this.pass1 = pass1;
    }
}
