package com.example.amiride;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class dashboard1 extends AppCompatActivity {
String enroll;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_dashboard1);
        Intent intent = getIntent();
        enroll = intent.getStringExtra("enroll");
        TextView txt=findViewById(R.id.txt);
        txt.setText("Welcome "+enroll);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ImageView home = findViewById(R.id.imageView3);
        ImageView acc = findViewById(R.id.imageView2);
        ImageView his = findViewById(R.id.imageView4);

        ImageView pub = findViewById(R.id.image1);
        ImageView rid = findViewById(R.id.image2);

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(dashboard1.this, dashboard1.class);
                startActivity(intent);
            }
        });

        acc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(dashboard1.this, account.class);
                intent.putExtra("enroll", enroll); // Attach the data
                startActivity(intent);
                startActivity(intent);
            }
        });

        his.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(dashboard1.this, history.class);
                startActivity(intent);
            }
        });



        pub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(dashboard1.this, publishride.class);
                startActivity(intent);
            }
        });

        rid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(dashboard1.this, bookride.class);
                startActivity(intent);
            }
        });




        //onclick funtions here

    }
}