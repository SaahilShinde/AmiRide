package com.example.amiride;

public class BookRideDB
{
    String  enroll,mobileno,from,time ,decrip ,vehicleno;
    public BookRideDB()
    {
}

    public BookRideDB(String enroll, String mobileno, String from, String time, String decrip, String vehicleno) {
        this.enroll = enroll;
        this.mobileno = mobileno;
        this.from = from;
        this.time = time;
        this.decrip = decrip;
        this.vehicleno = vehicleno;
    }

    public String getEnroll() {
        return enroll;
    }

    public void setEnroll(String enroll) {
        this.enroll = enroll;
    }

    public String getMobileno() {
        return mobileno;
    }

    public void setMobileno(String mobileno) {
        this.mobileno = mobileno;
    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getDecrip() {
        return decrip;
    }

    public void setDecrip(String decrip) {
        this.decrip = decrip;
    }

    public String getVehicleno() {
        return vehicleno;
    }

    public void setVehicleno(String vehicleno) {
        this.vehicleno = vehicleno;
    }
}
