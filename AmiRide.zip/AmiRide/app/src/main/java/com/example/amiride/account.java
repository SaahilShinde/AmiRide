package com.example.amiride;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class account extends AppCompatActivity {
String enroll;
String pass;
DatabaseReference db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_account);
        Intent intent = getIntent();
        enroll = intent.getStringExtra("enroll");
        db= FirebaseDatabase.getInstance().getReference().child("StudentSignup");
        EditText fname=findViewById(R.id.fname);
        EditText lname=findViewById(R.id.lname);
        EditText contact=findViewById(R.id.contact);
        EditText email=findViewById(R.id.email);
        TextView enr=findViewById(R.id.enr);
        Button save=findViewById(R.id.next123);
        db.child(enroll).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DataSnapshot> task) {

                String fname1=task.getResult().child("fname1").getValue(String.class);
                String lname1=task.getResult().child("lname1").getValue(String.class);
                String contact1=task.getResult().child("conta1").getValue(String.class);
                String email1=task.getResult().child("emai1").getValue(String.class);
                String pass1=task.getResult().child("pass1").getValue(String.class);

                fname.setText(fname1);
                lname.setText(lname1);
                contact.setText(contact1);
                email.setText(email1);
                enr.setText(enroll);
                pass=pass1;
            }
        });
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ImageView back = findViewById(R.id.imageView6);
        back.setOnClickListener(v -> {
            finish();
        });

        save.setOnClickListener(v -> {
            if(fname.getText().toString().isEmpty() || lname.getText().toString().isEmpty() || contact.getText().toString().isEmpty() || email.getText().toString().isEmpty()){
                Toast.makeText(account.this, "Fill all fields", Toast.LENGTH_SHORT).show();
            }
            else {
                String fname1=fname.getText().toString();
                String lname1=lname.getText().toString();
                String contact1=contact.getText().toString();
                String email1=email.getText().toString();
                StudSignup f = new StudSignup(fname1, lname1, contact1, email1, enroll, pass);
                db.child(enroll).setValue(f);

                Toast.makeText(account.this, "Account Updated Successfully", Toast.LENGTH_SHORT).show();
            }

        });


    }
}