package com.example.amiride;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class signup extends AppCompatActivity {
String fname1, lname1, conta1, emai1, user1, pass1;
DatabaseReference db;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_signup2);
        db= FirebaseDatabase.getInstance().getReference().child("StudentSignup");
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        EditText fname, lname, conta, emai, user, pass;
        Button create;

        fname = findViewById(R.id.one);
        lname = findViewById(R.id.two);
        conta = findViewById(R.id.ten);
        emai = findViewById(R.id.four);
        user = findViewById(R.id.five);
        pass = findViewById(R.id.six);

        create = findViewById(R.id.btn1);

        create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fname1 = fname.getText().toString();
                lname1=lname.getText().toString();
                conta1=conta.getText().toString();
                emai1=emai.getText().toString();
                user1=user.getText().toString();
                pass1=pass.getText().toString();

                if(fname.getText().toString().isEmpty() || lname.getText().toString().isEmpty() || conta.getText().toString().isEmpty() || emai.getText().toString().isEmpty() || user.getText().toString().isEmpty() || pass.getText().toString().isEmpty()){

                    Toast.makeText(signup.this, "Fill all fields", Toast.LENGTH_SHORT).show();
                }
                else {
                    StudSignup f = new StudSignup(fname1, lname1, conta1, emai1, user1, pass1);
                   db.child(user1).setValue(f);

                    Toast.makeText(signup.this, "Account Created Successfully", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(signup.this, dashboard1.class);
                    startActivity(intent);
                }
            }
        });


    }
}